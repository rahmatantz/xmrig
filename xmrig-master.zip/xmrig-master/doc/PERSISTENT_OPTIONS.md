# Persistent options

Options in list below can't changed in runtime by watching config file or via API.

* `background`
* `donate-level`
* `cpu/argon2-impl`
* `opencl/loader`
* `opencl/platform`
